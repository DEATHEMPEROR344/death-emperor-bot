{
  "devMode": true,
  "timeZone": "Asia/Dhaka",
  "prefix": "!",
  "symbols": "●",
  "owner": {
    "name": "DEATH EMPEROR DEV",
    "username": "Deathempero_2006"
  },
  "admin": [
    "8239530651"
  ],
  "vip": [
    "VIP_UID"
  ],
  "loadCmds": true,
  "loadEvents": true,
  "groups": {
    "noAdmin": true,
    "whitelist": false,
    "list": [
      "1002497269617",
      "1003113990675"
    ]
  },
  "inbox": {
    "enabled": true
  },
  "mongoDB": {
    "enabled": false,
    "url": "MONGODB_URL",
    "dbName": "DATABASE_NAME"
  },
  "apiKeys": {
    "gemini": "",
    "openai": ""
  }
}