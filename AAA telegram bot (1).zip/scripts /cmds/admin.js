const fs = require("fs");
const path = require("path");

const configPath = path.join(__dirname, "..", "..", "config.json");

function loadConfig() {
  try {
    const configData = fs.readFileSync(configPath, "utf-8");
    const config = JSON.parse(configData);

    if (!config.admin) {
      config.admin = [];
    }

    return config;
  } catch (error) {
    console.error("Error loading config.json:", error);
    return { admin: [], symbols: "●", prefix: "!" };
  }
}

function saveConfig(config) {
  try {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  } catch (error) {
    console.error("Error saving config.json:", error);
  }
}

async function getAdminName(userId, bot, chatId) {
  try {
    const chatMember = await bot.getChatMember(chatId, userId);
    const user = chatMember.user;

    let userName = user.first_name || "Unknown";
    if (user.last_name) {
      userName += ` ${user.last_name}`;
    }

    return `${userName}\n(${userId})`;
  } catch (e) {
    return `User_${userId}\n(${userId})`;
  }
}

module.exports = {
  nix: {
    name: "admin",
    prefix: false,
    admin: true,
    vip: true,
    role: 2,
    author: "DEATH EMPEROR BUTTERFLY DEV 👑",
    version: "1.0.0-DBK",
    description: "Manage bot administrators: add, remove, list",
    usage: "!admin add [reply/mention/ID] | !admin remove [reply/mention/ID] | !admin list",
    category: "admin",
    aliases: ["ad"]
  },

  async onStart({ bot, message, args, chatId, userId }) {
    const config = loadConfig();
    const symbol = config.symbols || "●";
    const prefix = config.prefix || "!";

    // 🔒 Check if user is bot admin
    if (!config.admin.includes(String(userId))) {
      return message.reply("❌ | Only bot administrators can use this command.");
    }

    if (!args.length) {
      return message.reply(
        `${symbol} Usage:\n` +
        `\`${prefix}admin add [reply/mention/ID]\`\n` +
        `\`${prefix}admin remove [reply/mention/ID]\`\n` +
        `\`${prefix}admin list\``
      );
    }

    const subCmd = args[0].toLowerCase();

    // 📋 LIST ADMINS
    if (subCmd === "list") {
      const admins = config.admin;

      if (admins.length === 0) {
        return message.reply(`${symbol} No bot administrators found.`);
      }

      const adminNames = await Promise.all(
        admins.map(async (adminId) => {
          return await getAdminName(adminId, bot, chatId);
        })
      );

      const text =
        "👑 | List of Bot Administrators:\n\n" +
        adminNames.map(n => `• ${n}`).join("\n\n");

      return message.reply(text);
    }

    if (!["add", "remove"].includes(subCmd)) {
      return message.reply(
        `${symbol} Invalid subcommand. Use: \`add\`, \`remove\`, or \`list\`.`
      );
    }

    let targetUsers = [];

    // 📌