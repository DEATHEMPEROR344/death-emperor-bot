const nix = {
  nix: {
    name: "tagall",
    aliases: ["everyone", "all"],
    version: "1.0.0",
    author: "DEATH EMPEROR DEV",
    cooldowns: 10,
    role: 2, // seulement admin du bot
    description: "Mention all members in the group with a fixed message (bot admins only)",
    category: "UTILITY",
    guide: "Usage: {pn}"
  },

  onStart: async ({ bot, message, msg, chatId }) => {
    try {
      const botAdmins = global.config.admin; // IDs des admins du bot
      if (!botAdmins.includes(msg.from.id.toString())) {
        return message.reply("❌ Seuls les admins du bot peuvent utiliser cette commande !");
      }

      // Récupérer les membres du groupe
      const members = await bot.getChatMembers(chatId);

      if (!members || members.length === 0) {
        return message.reply("❌ Impossible de récupérer les membres du groupe.");
      }

      // Filtrer les bots et créer les mentions HTML
      const mentions = members
        .filter(m => m.user && !m.user.is_bot)
        .map(m => `<a href="tg://user?id=${m.user.id}">${m.user.first_name}</a>`);

      const chunkSize = 20; // Envoi par petits groupes
      for (let i = 0; i < mentions.length; i += chunkSize) {
        const chunk = mentions.slice(i, i + chunkSize).join(" ");
        await bot.sendMessage(chatId, `DEATH EMPEROR DEV EST LÀ\n${chunk}`, { parse_mode: "HTML" });
      }

      await message.reply("✅ Tous les membres ont été mentionnés !");
    } catch (err) {
      console.error("Tagall Error:", err);
      await message.reply(`❌ Erreur : ${err.message}`);
    }
  }
};

module.exports = nix;