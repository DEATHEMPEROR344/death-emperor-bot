const path = require('path');

module.exports = {
  nix: {
    name: 'help',
    prefix: false,
    role: 0,
    category: 'utility',
    aliases: ['commands'],
    author: 'DEATH EMPEROR BUTTERFLY DEV 👑',
    version: '0.0.1-DBK',
  },

  async onStart({ bot, message, args }) {
    if (!global.teamnix || !global.teamnix.cmds) {
      return message.reply("Command collection is not available.");
    }
    const commands = global.teamnix.cmds;

    // Si un nom de commande est donné
    if (args.length) {
      const query = args[0].toLowerCase();
      const cmd = [...commands.values()].find(
        c => c.nix.name === query || (c.nix.aliases && c.nix.aliases.includes(query))
      );
      if (!cmd) return message.reply(`No command called “${query}”.`);
      const info = cmd.nix;
      const detail = `
╭─────────────────────◊
│ ▸ Command: ${info.name}
│ ▸ Aliases: ${info.aliases?.length ? info.aliases.join(', ') : 'None'}
│ ▸ Can use: ${info.role === 2 ? 'Admin Only' : info.role === 1 ? 'VIP Only' : 'All Users'}
│ ▸ Category: ${info.category?.toUpperCase() || 'UNCATEGORIZED'}
│ ▸ PrefixEnabled?: ${info.prefix === false ? 'False' : 'True'}
│ ▸ Author: ${info.author || 'Unknown'}
│ ▸ Version: ${info.version || 'N/A'}
╰─────────────────────◊
      `.trim();
      return message.reply(detail);
    }

    // Regroupement par catégorie
    const cats = {};
    [...commands.values()]
      .filter((command, index, self) =>
        index === self.findIndex((c) => c.nix.name === command.nix.name)
      )
      .forEach(c => {
        const cat = c.nix.category || 'UNCATEGORIZED';
        if (!cats[cat]) cats[cat] = [];
        if (!cats[cat].includes(c.nix.name)) cats[cat].push(c.nix.name);
      });

    // Création du message
    let msg = '';
    Object.keys(cats).sort().forEach(cat => {
      msg += `╭─────『 ${cat.toUpperCase()} 』\n`;
      cats[cat].sort().forEach(n => {
        msg += `│ ▸ ${n}\n`;
      });
      msg += `╰──────────────\n`;
    });

    msg += `
╭──────────────◊
│ » Total commands: ${[...new Set(commands.values())].length}
│ » A Powerful Telegram bot
│ » DEATH EMPEROR BUTTERFLY DEV
╰──────────◊
「 Nix bot 」
    `.trim();

    // Envoi du texte
    await message.reply(msg);

    // Envoi de l'image Death.jpg
    const imagePath = path.join(__dirname, '..', '..', 'Assets', 'Death.jpg');
    await bot.sendPhoto(message.chat.id, imagePath, { caption: "👑 DEATH EMPEROR BUTTERFLY" }).catch(console.error);

    // Envoi de l'audio Death.mp3
    const audioPath = path.join(__dirname, '..', '..', 'Assets', 'Death.mp3');
    await bot.sendAudio(message.chat.id, audioPath, { caption: "🎵 DEATH THEME" }).catch(console.error);
  }
};