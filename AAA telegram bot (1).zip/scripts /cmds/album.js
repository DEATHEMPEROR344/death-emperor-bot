const axios = require("axios");
const fs = require("fs");
const path = require("path");

const DEATH_API = "https://nix-album-api.vercel.app";

module.exports = {
  nix: {
    name: "album",
    version: "1.0.0-DBK",
    role: 0,
    author: "DEATH EMPEROR BUTTERFLY DEV 👑",
    description: "Send random videos from an album.",
    category: "media",
    cooldowns: 5,
    prefix: true,
  },

  onStart: async function ({ bot, message, msg, args, chatId }) {

    const categories = ["funny", "islamic", "sad", "anime", "lofi", "attitude", "ff", "love"];
    const displayNames = ["Funny", "Islamic", "Sad", "Anime", "LoFi", "Attitude", "FF", "Love"];

    if (!global.teamnix) {
      global.teamnix = {};
    }

    const getKeyboard = () => {
      const buttons = categories.map((cat, index) => ({
        text: displayNames[index],
        callback_data: `album_${cat}`,
      }));

      const keyboard = [];
      for (let i = 0; i < buttons.length; i += 2) {
        keyboard.push(buttons.slice(i, i + 2));
      }

      return {
        reply_markup: {
          inline_keyboard: keyboard,
        },
      };
    };

    // ➕ ADD VIDEO
    if (args[0] === "add") {

      const category = args[1]?.toLowerCase();
      let videoUrl = args[2];

      if (!category) {
        return message.reply("Usage: `!album add [category] [video_url]`", { parse_mode: "Markdown" });
      }

      if (msg.reply_to_message?.video) {
        videoUrl = msg.reply_to_message.video.file_id;
      }

      if (!videoUrl) {
        return message.reply("Reply to a video or provide a valid video URL.");
      }

      try {
        const addResponse = await axios.post(`${DEATH_API}/api/album/add`, { category, videoUrl });
        return message.reply(`✅ ${addResponse.data.message}`);
      } catch (error) {
        console.error(error);
        return message.reply(`❌ Failed to add video.\nError: ${error.response?.data?.error || error.message}`);
      }

    }

    // 📋 LIST CATEGORIES
    else if (args[0] === "list") {

      try {
        const response = await axios.get(`${DEATH_API}/api/category/list`);

        if (response.data.success) {
          const catList = response.data.categories
            .map((cat, index) => `${index + 1}. ${cat}`)
            .join("\n");

          return message.reply(`🎀 Available Album Categories:\n\n${catList}`);
        } else {
          return message.reply(`❌ ${response.data.error}`);
        }

      } catch (error) {
        return message.reply("❌ Error while fetching categories. Try again later.");
      }

    }

    // 🎀 SHOW MENU
    else {

      const keyboardOptions = getKeyboard();

      await bot.sendMessage(
        chatId,
        "🎀 𝐀𝐯𝐚𝐢𝐥𝐚𝐛𝐥𝐞 𝐀𝐥𝐛𝐮𝐦 𝐕𝐢𝐝𝐞𝐨 𝐋𝐢𝐬𝐭\n\nSelect a category:",
        {
          ...keyboardOptions,
          parse_mode: "Markdown",
          reply_to_message_id: msg.message_id
        }
      );
    }
  },

  onCallback: async function ({ bot, callbackQuery, chatId, messageId }) {

    const header = "🎯 𝐀𝐥𝐛𝐮𝐦\n━━━━━━━━━━━━━\n\n";
    const data = callbackQuery.data;

    await bot.answerCallbackQuery(callbackQuery.id);

    if (data.startsWith("album_")) {

      const category = data.split('_')[1];

      const categoryNames = {
        funny: "Funny Video",
        islamic: "Islamic Video",
        sad: "Sad Video",
        anime: "Anime Video",
        lofi: "LoFi Video",
        attitude: "Attitude Video",
        ff: "FF Video",
        love: "Love Video"
      };

      await bot.editMessageText(
        `⏳ Loading: **${categoryNames[category]}**`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
        }
      );

      try {

        const response = await axios.get(`${DEATH_API}/api/album/videos/${category}`);

        if (!response.data.success || !response.data.videos || response.data.videos.length === 0) {

          return bot.editMessageText(
            header + `❌ No videos found for: **${categoryNames[category]}**`,
            {
              chat_id: chatId,
              message_id: messageId,
              parse_mode: "Markdown",
            }
          );
        }

        const videoUrls = response.data.videos;
        const randomVideoUrl = videoUrls[Math.floor(Math.random() * videoUrls.length)];

        await bot.sendVideo(
          chatId,
          randomVideoUrl,
          { caption: `💖 Here is your ${categoryNames[category]}` }
        );

        bot.deleteMessage(chatId, messageId);

      } catch (error) {

        console.error("Error fetching video:", error);

        await bot.editMessageText(
          header + "❌ An error occurred while fetching the video.",
          {
            chat_id: chatId,
            message_id: messageId,
          }
        );
      }
    }
  }
};